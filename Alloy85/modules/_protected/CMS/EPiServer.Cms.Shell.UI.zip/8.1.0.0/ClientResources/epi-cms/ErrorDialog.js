//>>built
define("epi-cms/ErrorDialog",["epi","epi/shell/widget/dialog/ErrorDialog"],function(_1,_2){_1.cms=_1.cms||{};return _1.cms.ErrorDialog=_2;});